var managePurchaseTable;
var purchaseRowCount;

$(document).ready(function() {
	// top nav active
	$('#navPurchase').addClass('active');

	// manage purchase table (DataTable)
	managePurchaseTable = $("#managePurchaseTable").DataTable({
		'ajax': 'php_action/fetchPurchase.php',
		'order': []
	});

	// Barcode scan handler for purchase (Enter key)
	$("#barcodeScanPurchase").keypress(function(e) {
		if(e.which == 13) {
			e.preventDefault();
			var barcode = $(this).val().trim();
			processBarcodePurchase(barcode);
		}
	});

	// Camera scan button for purchase -- check availability first
	var html5QrCodePurchase;
	var cameraAvailablePurchase = false;

	// Test if camera API is available (requires HTTPS or localhost)
	if(typeof Html5Qrcode !== 'undefined' && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
		Html5Qrcode.getCameras().then(function(devices) {
			if(devices && devices.length > 0) {
				cameraAvailablePurchase = true;
				$("#cameraScanPurchaseBtn").prop('disabled', false)
					.attr('title', 'Scan with phone camera')
					.removeClass('btn-default').addClass('btn-info');
			}
		}).catch(function() {
			// Camera detection failed -- button stays disabled
		});
	}

	$("#cameraScanPurchaseBtn").click(function() {
		if(!cameraAvailablePurchase) {
			$("#barcodeScanFeedbackPurchase")
				.text("Camera requires HTTPS or localhost. Use hardware scanner or type barcode manually.")
				.show();
			return;
		}
		$("#barcodeScanFeedbackPurchase").hide();
		$("#cameraViewfinderPurchase").slideDown();
		startCameraScanPurchase();
	});

	// Stop camera button for purchase
	$("#stopCameraPurchaseBtn").click(function() {
		stopCameraScanPurchase();
	});

	function processBarcodePurchase(barcode) {
		if(barcode == "") return;
		$.ajax({
			url: 'php_action/fetchProductByBarcode.php',
			type: 'post',
			data: {barcode: barcode},
			dataType: 'json',
			success:function(response) {
				if(response) {
					var found = false;
					var tableLength = $("#productTable tbody tr").length;
					for(var i = 0; i < tableLength; i++) {
						var tr = $("#productTable tbody tr")[i];
						var rowId = $(tr).attr('id');
						if(rowId) {
							var count = rowId.substring(3);
							if($("#productName"+count).val() == response[0]) {
								var currentQty = parseInt($("#quantity"+count).val()) || 0;
								$("#quantity"+count).val(currentQty + 1);
								getTotal(count);
								found = true;
								break;
							}
						}
					}
					if(!found) {
						addRow();
						setTimeout(function() {
							var lastTr = $("#productTable tbody tr:last");
							var lastCount = lastTr.attr('id').substring(3);
							$("#productName"+lastCount).val(response[0]);
							getProductData(lastCount);
						}, 500);
					}
					$("#barcodeScanFeedbackPurchase").hide();
				} else {
					$("#barcodeScanFeedbackPurchase").text("Barcode not found!").show();
				}
				$("#barcodeScanPurchase").val("").focus();
			}
		});
	}

	function startCameraScanPurchase() {
		html5QrCodePurchase = new Html5Qrcode("cameraPreviewPurchase");
		html5QrCodePurchase.start(
			{ facingMode: "environment" },
			{ fps: 10, qrbox: { width: 250, height: 120 } },
			function(decodedText) {
				$("#barcodeScanPurchase").val(decodedText);
				processBarcodePurchase(decodedText);
				stopCameraScanPurchase();
			},
			function(errorMessage) {
				// Scanning in progress, ignore
			}
		).catch(function(err) {
			$("#barcodeScanFeedbackPurchase").text("Camera error: " + err).show();
			$("#cameraViewfinderPurchase").slideUp();
		});
	}

	function stopCameraScanPurchase() {
		if(html5QrCodePurchase) {
			html5QrCodePurchase.stop().then(function() {
				$("#cameraViewfinderPurchase").slideUp();
				html5QrCodePurchase.clear();
			}).catch(function(err) {
				$("#cameraViewfinderPurchase").slideUp();
			});
		}
	}

	// add purchase form submission
	$("#createPurchaseForm").unbind('submit').bind('submit', function() {
		
		var form = $(this);

		// validate
		var purchaseDate = $("#purchaseDate").val();
		var supplierId = $("#supplierId").val();
		var productName = $("#productName1").val();

		if(purchaseDate == "") {
			$("#purchaseDate").after('<p class="text-danger">Purchase Date field is required</p>');
			$('#purchaseDate').closest('.form-group').addClass('has-error');
		} else {
			$("#purchaseDate").find('.text-danger').remove();
			$('#purchaseDate').closest('.form-group').addClass('has-success');
		}

		if(supplierId == "") {
			$("#supplierId").after('<p class="text-danger">Supplier field is required</p>');
			$('#supplierId').closest('.form-group').addClass('has-error');
		} else {
			$("#supplierId").find('.text-danger').remove();
			$('#supplierId').closest('.form-group').addClass('has-success');
		}

		if(productName == "") {
			$("#productName1").after('<p class="text-danger">Please select a product</p>');
			$('#productName1').closest('.form-group').addClass('has-error');
		} else {
			$("#productName1").find('.text-danger').remove();
			$('#productName1').closest('.form-group').addClass('has-success');
		}

		if(purchaseDate && supplierId && productName) {
			$("#createPurchaseBtn").button('loading');

			$.ajax({
				url: form.attr('action'),
				type: form.attr('method'),
				data: form.serialize(),
				dataType: 'json',
				success:function(response) {
					$("#createPurchaseBtn").button('reset');

					if(response.success == true) {
						$(".success-messages").html('<div class="alert alert-success">'+
				            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
				            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
				          '</div>');

			  			$(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						});

						// reload manage purchase table
						if(managePurchaseTable){
							managePurchaseTable.ajax.reload(null, false);
						}

						// reset form
						$("#createPurchaseForm")[0].reset();
						$('.text-danger').remove();
						$('.form-group').removeClass('has-error').removeClass('has-success');
					} else {
						$(".success-messages").html('<div class="alert alert-danger">'+
				            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
				            '<strong><i class="glyphicon glyphicon-remove-sign"></i></strong> '+ response.messages +
				          '</div>');
					}
				} // /success
			}); // /ajax
		} // /if

		return false;
	}); // /create purchase form

	// edit purchase form submission
	$("#editPurchaseForm").unbind('submit').bind('submit', function() {
		
		var form = $(this);

		$("#editPurchaseBtn").button('loading');

		$.ajax({
			url: form.attr('action'),
			type: form.attr('method'),
			data: form.serialize(),
			dataType: 'json',
			success:function(response) {
				$("#editPurchaseBtn").button('reset');

				if(response.success == true) {
					$(".success-messages").html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
			          '</div>');

		  			$(".alert-success").delay(500).show(10, function() {
						$(this).delay(3000).hide(10, function() {
							$(this).remove();
						});
					});

					// reload manage purchase table
					if(managePurchaseTable){
						managePurchaseTable.ajax.reload(null, false);
					}
				} else {
					$(".success-messages").html('<div class="alert alert-danger">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-remove-sign"></i></strong> '+ response.messages +
			          '</div>');
				}
			} // /success
		}); // /ajax

		return false;
	}); // /edit purchase form

	// remove purchase button click
	$("#removePurchaseBtn").unbind('click').bind('click', function() {
		var purchaseId = $("#removePurchaseId").val();

		$("#removePurchaseBtn").button('loading');

		$.ajax({
			url: 'php_action/removePurchase.php',
			type: 'post',
			data: {purchaseId: purchaseId},
			dataType: 'json',
			success:function(response) {
				$("#removePurchaseBtn").button('reset');

				if(response.success == true) {
					$("#removePurchaseModal").modal('hide');

					managePurchaseTable.ajax.reload(null, false);

					$(".removePurchaseMessages").html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
			          '</div>');

		  			$(".alert-success").delay(500).show(10, function() {
						$(this).delay(3000).hide(10, function() {
							$(this).remove();
						});
					});
				}
			}
		});
	});

}); // /document ready

// add row to product table
function addRow() {
	var tableLength = $("#productTable tbody tr").length;
	var tableRow;
	var arrayNumber;
	var count;

	if(tableLength > 0) {
		tableRow = $("#productTable tbody tr:last").attr('id');
		arrayNumber = $("#productTable tbody tr:last").attr('class');
		count = tableRow.substring(3);
		count = Number(count) + 1;
		arrayNumber = Number(arrayNumber) + 1;
	} else {
		count = 1;
		arrayNumber = 0;
	}

	$.ajax({
		url: 'php_action/fetchProduct.php',
		type: 'post',
		dataType: 'json',
		success:function(response) {
			$("#productTable tbody").append(
				'<tr id="row'+count+'" class="'+arrayNumber+'">'+
				'<td>'+
				'<div class="form-group">'+
				'<select class="form-control" name="productName[]" id="productName'+count+'" onchange="getProductData('+count+')" >'+
				'<option value="">~~SELECT~~</option>'+
				'</select>'+
				'</div>'+
				'</td>'+
				'<td style="padding-left:20px;">'+
				'<input type="text" name="rate[]" id="rate'+count+'" autocomplete="off" disabled="true" class="form-control" />'+
				'<input type="hidden" name="rateValue[]" id="rateValue'+count+'" autocomplete="off" class="form-control" />'+
				'</td>'+
				'<td style="padding-left:20px;">'+
				'<div class="form-group">'+
				'<p id="available_quantity'+count+'"></p>'+
				'</div>'+
				'</td>'+
				'<td style="padding-left:20px;">'+
				'<div class="form-group">'+
				'<input type="number" name="quantity[]" id="quantity'+count+'" onkeyup="getTotal('+count+')" autocomplete="off" class="form-control" min="1" />'+
				'</div>'+
				'</td>'+
				'<td style="padding-left:20px;">'+
				'<input type="text" name="total[]" id="total'+count+'" autocomplete="off" class="form-control" disabled="true" />'+
				'<input type="hidden" name="totalValue[]" id="totalValue'+count+'" autocomplete="off" class="form-control" />'+
				'</td>'+
				'<td>'+
				'<button class="btn btn-default removeProductRowBtn" type="button" onclick="removeProductRow('+count+')"><i class="glyphicon glyphicon-trash"></i></button>'+
				'</td>'+
				'</tr>'
			);

			// populate product dropdown
			$.each(response.data, function(index, value) {
				$('#productName'+count).append('<option value="'+value[0]+'">'+value[1]+'</option>');
			});
		} // /success
	}); // /ajax
}

// remove product row
function removeProductRow(row = null) {
	if(row) {
		$("#row"+row).remove();

		subAmount();
	}
}

// get product data (rate and quantity)
function getProductData(row = null) {
	if(row) {
		var productId = $("#productName"+row).val();
		if(productId == "") {
			$("#rate"+row).val("");
			$("#rateValue"+row).val("");
			$("#quantity"+row).val("");
			$("#total"+row).val("");
			$("#totalValue"+row).val("");
			$("#available_quantity"+row).text("");
		} else {
			$.ajax({
				url: 'php_action/fetchProductData.php',
				type: 'post',
				data: {productId: productId},
				dataType: 'json',
				success:function(response) {
					$("#rate"+row).val(response.rate);
					$("#rateValue"+row).val(response.rate);
					$("#available_quantity"+row).text(response.quantity);
					$("#quantity"+row).val(1);
					getTotal(row);
				} // /success
			}); // /ajax
		}
	}
}

// calculate row total
function getTotal(row = null) {
	if(row) {
		var total = Number($("#rateValue"+row).val()) * Number($("#quantity"+row).val());
		total = total.toFixed(2);
		$("#total"+row).val(total);
		$("#totalValue"+row).val(total);

		subAmount();
	}
}

// calculate sub total, total amount, grand total
function subAmount() {
	var tableProductLength = $("#productTable tbody tr").length;
	var subTotal = 0;
	for(x = 1; x <= tableProductLength; x++) {
		var tr = $("#productTable tbody tr:nth-child("+x+")");
		var count = tr.attr('id');
		count = count.substring(3);

		var totalValue = Number($("#totalValue"+count).val());
		if(totalValue) {
			subTotal = Number(subTotal) + Number(totalValue);
		}
	} // /for

	subTotal = subTotal.toFixed(2);

	$("#subTotal").val(subTotal);
	$("#subTotalValue").val(subTotal);

	$("#totalAmount").val(subTotal);
	$("#totalAmountValue").val(subTotal);

	// calculate grand total with discount
	var discount = $("#discount").val();
	if(discount) {
		var grandTotal = Number(subTotal) - Number(discount);
		grandTotal = grandTotal.toFixed(2);
		$("#grandTotal").val(grandTotal);
		$("#grandTotalValue").val(grandTotal);
	} else {
		$("#grandTotal").val(subTotal);
		$("#grandTotalValue").val(subTotal);
	}

	// calculate due
	var paid = $("#paid").val();
	if(paid) {
		var grandTotalValue = $("#grandTotalValue").val();
		var due = Number(grandTotalValue) - Number(paid);
		due = due.toFixed(2);
		$("#due").val(due);
		$("#dueValue").val(due);
	} else {
		var grandTotalValue = $("#grandTotalValue").val();
		$("#due").val(grandTotalValue);
		$("#dueValue").val(grandTotalValue);
	}
}

// discount function
function discountFunc() {
	var discount = $("#discount").val();
	var subTotalValue = $("#subTotalValue").val();

	if(discount) {
		var grandTotal = Number(subTotalValue) - Number(discount);
		grandTotal = grandTotal.toFixed(2);
		$("#grandTotal").val(grandTotal);
		$("#grandTotalValue").val(grandTotal);
	} else {
		$("#grandTotal").val(subTotalValue);
		$("#grandTotalValue").val(subTotalValue);
	}

	// calculate due
	var paid = $("#paid").val();
	if(paid) {
		var grandTotalValue = $("#grandTotalValue").val();
		var due = Number(grandTotalValue) - Number(paid);
		due = due.toFixed(2);
		$("#due").val(due);
		$("#dueValue").val(due);
	} else {
		var grandTotalValue = $("#grandTotalValue").val();
		$("#due").val(grandTotalValue);
		$("#dueValue").val(grandTotalValue);
	}
}

// paid amount function
function paidAmount() {
	var paid = $("#paid").val();
	var grandTotalValue = $("#grandTotalValue").val();

	if(paid) {
		var due = Number(grandTotalValue) - Number(paid);
		due = due.toFixed(2);
		$("#due").val(due);
		$("#dueValue").val(due);
	} else {
		$("#due").val(grandTotalValue);
		$("#dueValue").val(grandTotalValue);
	}
}

// reset form
function resetPurchaseForm() {
	$("#createPurchaseForm")[0].reset();
	$('.text-danger').remove();
	$('.form-group').removeClass('has-error').removeClass('has-success');
}

// remove purchase function (called from manage table)
function removePurchase(purchaseId = null) {
	if(purchaseId) {
		$("#removePurchaseId").remove();
		$(".removePurchaseFooter").append('<input type="hidden" name="removePurchaseId" id="removePurchaseId" value="'+purchaseId+'" />');
	}
}