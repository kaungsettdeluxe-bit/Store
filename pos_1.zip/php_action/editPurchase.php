<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	
	$purchaseId = $_POST['purchaseId'];

	$purchaseDate           = date('Y-m-d', strtotime($_POST['purchaseDate']));
  $supplierId             = $_POST['supplierId'];
  $subTotalValue          = $_POST['subTotalValue'];
  $totalAmountValue       = $_POST['totalAmountValue'];
  $discount               = $_POST['discount'];
  $grandTotalValue        = $_POST['grandTotalValue'];
  $paid                   = $_POST['paid'];
  $dueValue               = $_POST['dueValue'];
  $paymentType            = $_POST['paymentType'];
  $paymentStatus          = $_POST['paymentStatus'];
	$userid                 = $_SESSION['userId'];
				
	$sql = "UPDATE purchase_orders SET purchase_date = '$purchaseDate', supplier_id = '$supplierId', sub_total = '$subTotalValue', total_amount = '$totalAmountValue', discount = '$discount', grand_total = '$grandTotalValue', paid = '$paid', due = '$dueValue', payment_type = '$paymentType', payment_status = '$paymentStatus', purchase_status = 1, user_id = '$userid' WHERE purchase_id = {$purchaseId}";	
	$connect->query($sql);
	
	$readyToUpdatePurchaseItem = false;
	// RESTORE product quantities (subtract what was previously added)
	for($x = 0; $x < count($_POST['productName']); $x++) {		
		$updateProductQuantitySql = "SELECT product.quantity FROM product WHERE product.product_id = ".$_POST['productName'][$x]."";
		$updateProductQuantityData = $connect->query($updateProductQuantitySql);			
			
		while ($updateProductQuantityResult = $updateProductQuantityData->fetch_row()) {
			// get old purchase item quantity to restore it
			$oldItemTableSql = "SELECT purchase_order_item.quantity FROM purchase_order_item WHERE purchase_order_item.purchase_id = {$purchaseId}";
			$oldItemResult = $connect->query($oldItemTableSql);
			$oldItemData = $oldItemResult->fetch_row();

			// subtract old quantity to restore product stock
			$editQuantity = $updateProductQuantityResult[0] - $oldItemData[0];							

			$updateQuantitySql = "UPDATE product SET quantity = $editQuantity WHERE product_id = ".$_POST['productName'][$x]."";
			$connect->query($updateQuantitySql);		
		} // while	
		
		if(count($_POST['productName']) == count($_POST['productName'])) {
			$readyToUpdatePurchaseItem = true;			
		}
	} // /for quantity

	// remove old purchase order items
	for($x = 0; $x < count($_POST['productName']); $x++) {			
		$removePurchaseSql = "DELETE FROM purchase_order_item WHERE purchase_id = {$purchaseId}";
		$connect->query($removePurchaseSql);	
	} // /for quantity

	if($readyToUpdatePurchaseItem) {
		// insert new purchase order items
		for($x = 0; $x < count($_POST['productName']); $x++) {			
			$updateProductQuantitySql = "SELECT product.quantity FROM product WHERE product.product_id = ".$_POST['productName'][$x]."";
			$updateProductQuantityData = $connect->query($updateProductQuantitySql);
			
			while ($updateProductQuantityResult = $updateProductQuantityData->fetch_row()) {
				// INCREASE product quantity for new purchase
				$updateQuantity[$x] = $updateProductQuantityResult[0] + $_POST['quantity'][$x];							
					// update product table
					$updateProductTable = "UPDATE product SET quantity = '".$updateQuantity[$x]."' WHERE product_id = ".$_POST['productName'][$x]."";
					$connect->query($updateProductTable);

					// add into purchase_order_item
				$purchaseItemSql = "INSERT INTO purchase_order_item (purchase_id, product_id, quantity, rate, total, purchase_item_status) 
				VALUES ({$purchaseId}, '".$_POST['productName'][$x]."', '".$_POST['quantity'][$x]."', '".$_POST['rateValue'][$x]."', '".$_POST['totalValue'][$x]."', 1)";

				$connect->query($purchaseItemSql);		
			} // while	
		} // /for quantity
	}

	

	$valid['success'] = true;
	$valid['messages'] = "Successfully Updated";		
	
	$connect->close();

	echo json_encode($valid);
 
} // /if $_POST