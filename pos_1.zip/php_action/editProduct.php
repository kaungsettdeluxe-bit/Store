<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {
	$productId = $_POST['productId'];
	$productName 		= $_POST['editProductName']; 
	$barcode 			= $_POST['editBarcode'];
  $quantity 			= $_POST['editQuantity'];
  $rate 					= $_POST['editRate'];
  $brandName 			= $_POST['editBrandName'];
  $categoryName 	= $_POST['editCategoryName'];
  $productStatus 	= $_POST['editProductStatus'];

	// Get the old quantity before update
	$oldQtySql = "SELECT quantity FROM product WHERE product_id = $productId";
	$oldQtyResult = $connect->query($oldQtySql);
	$oldQtyData = $oldQtyResult->fetch_row();
	$oldQuantity = $oldQtyData[0];
					
	$sql = "UPDATE product SET product_name = '$productName', barcode = '$barcode', brand_id = '$brandName', categories_id = '$categoryName', quantity = '$quantity', rate = '$rate', active = '$productStatus', status = 1 WHERE product_id = $productId ";

	if($connect->query($sql) === TRUE) {
		// Log stock movement if quantity changed
		if($oldQuantity != $quantity) {
			$qtyDiff = abs($quantity - $oldQuantity);
			$movementType = ($quantity > $oldQuantity) ? 'IN' : 'OUT';
			$userId = $_SESSION['userId'];
			$movementSql = "INSERT INTO stock_movement (product_id, movement_type, quantity, previous_quantity, new_quantity, reason, reference_type, reference_id, user_id)
				VALUES ('$productId', '$movementType', '$qtyDiff', '$oldQuantity', '$quantity', 'Manual Adjustment', 'adjustment', NULL, '$userId')";
			$connect->query($movementSql);
		}

		$valid['success'] = true;
		$valid['messages'] = "Successfully Update";	
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while updating product info";
	}

} // /$_POST
	 
$connect->close();

echo json_encode($valid);
 
