<?php 	

require_once 'core.php';

$sql = "SELECT purchase_id, purchase_date, supplier_id, payment_status FROM purchase_orders WHERE purchase_status = 1";
$result = $connect->query($sql);


$output = array('data' => array());

if($result->num_rows > 0) { 
 
 $paymentStatus = ""; 
 $x = 1;

 while($row = $result->fetch_array()) {
 	$purchaseId = $row[0];

 	// get supplier name
 	$supplierSql = "SELECT supplier_name FROM suppliers WHERE supplier_id = ".$row[2]."";
 	$supplierResult = $connect->query($supplierSql);
 	$supplierRow = $supplierResult->fetch_row();

 	$countPurchaseItemSql = "SELECT count(*) FROM purchase_order_item WHERE purchase_id = $purchaseId";
 	$itemCountResult = $connect->query($countPurchaseItemSql);
 	$itemCountRow = $itemCountResult->fetch_row();


 	// active 
 	if($row[3] == 1) { 		
 		$paymentStatus = "<label class='label label-success'>Full Payment</label>";
 	} else if($row[3] == 2) { 		
 		$paymentStatus = "<label class='label label-info'>Advance Payment</label>";
 	} else { 		
 		$paymentStatus = "<label class='label label-warning'>No Payment</label>";
 	} // /else

 	$button = '<!-- Single button -->
	<div class="btn-group">
	  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	    Action <span class="caret"></span>
	  </button>
	  <ul class="dropdown-menu">
	    <li><a href="purchase.php?o=editOrd&i='.$purchaseId.'" id="editPurchaseModalBtn"> <i class="glyphicon glyphicon-edit"></i> Edit</a></li>
	    
	    <li><a type="button" data-toggle="modal" data-target="#removePurchaseModal" id="removePurchaseModalBtn" onclick="removePurchase('.$purchaseId.')"> <i class="glyphicon glyphicon-trash"></i> Remove</a></li>       
	  </ul>
	</div>';		

 	$output['data'][] = array( 		
 		$x,
 		// purchase date
 		$row[1],
 		// supplier name
 		$supplierRow[0], 
 		// item count		 	
 		$itemCountRow, 		 	
 		$paymentStatus,
 		// button
 		$button 		
 		); 	
 	$x++;
 } // /while 

}// if num_rows

$connect->close();

echo json_encode($output);