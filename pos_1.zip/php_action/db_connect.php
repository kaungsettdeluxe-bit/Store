<?php 	

$localhost = "localhost";
$username = "thebertg_admin";
$password = "thebertg_admin";
$dbname = "thebertg_pos";
$store_url = "//104.253.175.163/pos/";
// db 
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>
