<?php 	

require_once 'core.php';

$barcode = $_POST['barcode'];

$sql = "SELECT product_id, product_name, barcode, rate, quantity FROM product WHERE barcode = '$barcode' AND status = 1 AND active = 1 LIMIT 1";
$result = $connect->query($sql);

if($result->num_rows > 0) {
	$row = $result->fetch_array();
	echo json_encode($row);
} else {
	echo json_encode(null);
}

$connect->close();
