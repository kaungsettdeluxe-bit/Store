<?php 	

require_once 'core.php';

$purchaseId = $_POST['purchaseId'];

$valid = array('purchase' => array(), 'purchase_item' => array());

$sql = "SELECT purchase_orders.purchase_id, purchase_orders.purchase_date, purchase_orders.supplier_id, purchase_orders.sub_total, purchase_orders.total_amount, purchase_orders.discount, purchase_orders.grand_total, purchase_orders.paid, purchase_orders.due, purchase_orders.payment_type, purchase_orders.payment_status FROM purchase_orders 	
	WHERE purchase_orders.purchase_id = {$purchaseId}";

$result = $connect->query($sql);
$data = $result->fetch_row();
$valid['purchase'] = $data;


$connect->close();

echo json_encode($valid);