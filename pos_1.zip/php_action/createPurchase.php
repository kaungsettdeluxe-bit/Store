<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array(), 'purchase_id' => '');

if($_POST) {	

	$purchaseDate           = date('Y-m-d', strtotime($_POST['purchaseDate']));	
  $supplierId             = $_POST['supplierId'];
  $subTotalValue          = $_POST['subTotalValue'];
  $totalAmountValue       = $_POST['totalAmountValue'];
  $discount               = $_POST['discount'];
  $grandTotalValue        = $_POST['grandTotalValue'];
  $paid                   = $_POST['paid'];
  $dueValue               = $_POST['dueValue'];
  $paymentType            = $_POST['paymentType'];
  $paymentStatus          = $_POST['paymentStatus'];
  $userid                 = $_SESSION['userId'];

	$sql = "INSERT INTO purchase_orders (purchase_date, supplier_id, sub_total, total_amount, discount, grand_total, paid, due, payment_type, payment_status, purchase_status, user_id) 
	        VALUES ('$purchaseDate', '$supplierId', '$subTotalValue', '$totalAmountValue', '$discount', '$grandTotalValue', '$paid', '$dueValue', $paymentType, $paymentStatus, 1, $userid)";
	
	$purchase_id;
	$purchaseStatus = false;
	if($connect->query($sql) === true) {
		$purchase_id = $connect->insert_id;
		$valid['purchase_id'] = $purchase_id;	
		$purchaseStatus = true;
	}

	$purchaseItemStatus = false;

	for($x = 0; $x < count($_POST['productName']); $x++) {			
		$updateProductQuantitySql = "SELECT product.quantity FROM product WHERE product.product_id = ".$_POST['productName'][$x]."";
		$updateProductQuantityData = $connect->query($updateProductQuantitySql);
		
		while ($updateProductQuantityResult = $updateProductQuantityData->fetch_row()) {
			$previousQty = $updateProductQuantityResult[0];
			// INCREASE product quantity on purchase (receiving stock)
			$updateQuantity[$x] = $previousQty + $_POST['quantity'][$x];							
				// update product table
				$updateProductTable = "UPDATE product SET quantity = '".$updateQuantity[$x]."' WHERE product_id = ".$_POST['productName'][$x]."";
				$connect->query($updateProductTable);

				// add into purchase_order_item
				$purchaseItemSql = "INSERT INTO purchase_order_item (purchase_id, product_id, quantity, rate, total, purchase_item_status) 
				VALUES ('$purchase_id', '".$_POST['productName'][$x]."', '".$_POST['quantity'][$x]."', '".$_POST['rateValue'][$x]."', '".$_POST['totalValue'][$x]."', 1)";

				$connect->query($purchaseItemSql);

				// Log stock movement: purchase stock-in
				$movementSql = "INSERT INTO stock_movement (product_id, movement_type, quantity, previous_quantity, new_quantity, reason, reference_type, reference_id, user_id)
					VALUES ('".$_POST['productName'][$x]."', 'IN', '".$_POST['quantity'][$x]."', '$previousQty', '".$updateQuantity[$x]."', 'Purchase #$purchase_id', 'purchase', '$purchase_id', '$userid')";
				$connect->query($movementSql);

				if($x == count($_POST['productName'])) {
					$purchaseItemStatus = true;
				}		
		} // while	
	} // /for quantity

	$valid['success'] = true;
	$valid['messages'] = "Successfully Added";		
	
	$connect->close();

	echo json_encode($valid);
 
} // /if $_POST
