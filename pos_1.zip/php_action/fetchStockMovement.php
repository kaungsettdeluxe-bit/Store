<?php 	

require_once 'core.php';

$productId = $_POST['productId'];

$sql = "SELECT sm.movement_id, sm.movement_type, sm.quantity, sm.previous_quantity, 
		sm.new_quantity, sm.reason, sm.reference_type, sm.reference_id, 
		sm.user_id, sm.created_at, users.username 
		FROM stock_movement sm 
		LEFT JOIN users ON sm.user_id = users.user_id 
		WHERE sm.product_id = $productId 
		ORDER BY sm.created_at DESC";

$result = $connect->query($sql);

$output = array('data' => array());

if($result->num_rows > 0) { 
	while($row = $result->fetch_array()) {
		// movement type badge
		if($row[1] == 'IN') {
			$typeBadge = "<label class='label label-success'>IN</label>";
		} else if($row[1] == 'OUT') {
			$typeBadge = "<label class='label label-danger'>OUT</label>";
		} else {
			$typeBadge = "<label class='label label-warning'>ADJUST</label>";
		}

		$output['data'][] = array(
			$row[10],                          // username
			$typeBadge,                        // movement type
			$row[2],                           // quantity moved
			$row[3],                           // previous qty
			$row[4],                           // new qty
			$row[5],                           // reason
			date('d M Y, h:i A', strtotime($row[9]))  // date
		);
	}
}

$connect->close();

echo json_encode($output);
