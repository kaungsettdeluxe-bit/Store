<?php 
require_once 'php_action/db_connect.php'; 
require_once 'includes/header.php'; 

if($_GET['o'] == 'add') { 
// add purchase
	echo "<div class='div-request div-hide'>add</div>";
} else if($_GET['o'] == 'manord') { 
	echo "<div class='div-request div-hide'>manord</div>";
} else if($_GET['o'] == 'editOrd') { 
	echo "<div class='div-request div-hide'>editOrd</div>";
} // /else manage purchase


?>


<ol class="breadcrumb">
  <li><a href="dashboard.php">Home</a></li>
  <li>Purchase</li>
  <li class="active">
  	<?php if($_GET['o'] == 'add') { ?>
  		Add Purchase
		<?php } else if($_GET['o'] == 'manord') { ?>
			Manage Purchase
		<?php } else if($_GET['o'] == 'editOrd') { ?>
			Edit Purchase
		<?php } ?>
  </li>
</ol>


<h4>
	<i class='glyphicon glyphicon-circle-arrow-right'></i>
	<?php if($_GET['o'] == 'add') {
		echo "Add Purchase";
	} else if($_GET['o'] == 'manord') { 
		echo "Manage Purchase";
	} else if($_GET['o'] == 'editOrd') { 
		echo "Edit Purchase";
	}
	?>	
</h4>



<div class="panel panel-default">
	<div class="panel-heading">

		<?php if($_GET['o'] == 'add') { ?>
  		<i class="glyphicon glyphicon-plus-sign"></i>	Add Purchase
		<?php } else if($_GET['o'] == 'manord') { ?>
			<i class="glyphicon glyphicon-edit"></i> Manage Purchase
		<?php } else if($_GET['o'] == 'editOrd') { ?>
			<i class="glyphicon glyphicon-edit"></i> Edit Purchase
		<?php } ?>

	</div> <!--/panel-->	
	<div class="panel-body">
			
		<?php if($_GET['o'] == 'add') { 
			// add purchase
			?>			

			<div class="success-messages"></div> <!--/success-messages-->

  		<form class="form-horizontal" method="POST" action="php_action/createPurchase.php" id="createPurchaseForm">

			  <div class="form-group">
			    <label for="purchaseDate" class="col-sm-2 control-label">Purchase Date</label>
			    <div class="col-sm-10">
			      <input type="text" class="form-control" id="purchaseDate" name="purchaseDate" autocomplete="off" />
			    </div>
			  </div> <!--/form-group-->
			  <div class="form-group">
			    <label for="supplierId" class="col-sm-2 control-label">Supplier</label>
			    <div class="col-sm-10">
			      <select class="form-control" id="supplierId" name="supplierId">
			      	<option value="">~~SELECT~~</option>
			      	<?php
			      		$supplierSql = "SELECT * FROM suppliers WHERE supplier_active = 1 AND supplier_status = 1";
			      		$supplierData = $connect->query($supplierSql);
			      		while($row = $supplierData->fetch_array()) {
			      			echo "<option value='".$row['supplier_id']."'>".$row['supplier_name']."</option>";
			      		}
			      	?>
			      </select>
			    </div>
			  </div> <!--/form-group-->		  

			  			  <!-- Barcode Scan Input -->
			  <div class="form-group" style="margin-bottom:15px; background:#f9f9f9; padding:12px; border-radius:4px; border:1px dashed #ccc;">
			    <label for="barcodeScanPurchase" class="col-sm-2 control-label" style="padding-top:7px;">
			      <i class="glyphicon glyphicon-barcode" style="font-size:18px;"></i> Scan Barcode:
			    </label>
			    <div class="col-sm-4">
			      <div class="input-group">
			        <input type="text" class="form-control input-lg" id="barcodeScanPurchase" name="barcodeScanPurchase" placeholder="Scan or type barcode..." autocomplete="off" autofocus style="font-size:16px;" />
			        <span class="input-group-btn">
			          <button class="btn btn-default btn-lg" type="button" id="cameraScanPurchaseBtn" disabled title="Camera unavailable">
			            <i class="glyphicon glyphicon-camera"></i>
			          </button>
			        </span>
			      </div>
			    </div>
			    <div class="col-sm-6">
			      <span id="barcodeScanFeedbackPurchase" class="text-danger" style="display:none;"></span>
			      <small class="text-muted">Type + Enter, or tap <i class="glyphicon glyphicon-camera"></i> to use camera</small>
			    </div>
			  </div>
			  <!-- Camera Viewfinder -->
			  <div id="cameraViewfinderPurchase" style="display:none; margin-bottom:15px; text-align:center;">
			    <div id="cameraPreviewPurchase" style="width:100%; max-width:400px; margin:0 auto; border-radius:8px; overflow:hidden; border:2px solid #337ab7;"></div>
			    <button class="btn btn-default btn-sm" type="button" id="stopCameraPurchaseBtn" style="margin-top:8px;">
			      <i class="glyphicon glyphicon-stop"></i> Stop Camera
			    </button>
			  </div>
			  <!-- /Camera Viewfinder -->
			  <div style="clear:both;"></div>
			  <!-- /Barcode Scan --><!-- /Barcode Scan -->

			  <table class="table" id="productTable">
			  	<thead>
			  		<tr>			  			
			  			<th style="width:40%;">Product</th>
			  			<th style="width:20%;">Rate</th>
			  			<th style="width:10%;">In Stock</th>
			  			<th style="width:15%;">Quantity</th>			  			
			  			<th style="width:25%;">Total</th>			  			
			  			<th style="width:10%;"></th>
			  		</tr>
			  	</thead>
			  	<tbody>
			  		<?php
			  		$arrayNumber = 0;
			  		for($x = 1; $x < 2; $x++) { ?>
			  			<tr id="row<?php echo $x; ?>" class="<?php echo $arrayNumber; ?>">			  				
			  				<td style="margin-left:20px;">
			  					<div class="form-group">

				  					<select class="form-control" name="productName[]" id="productName<?php echo $x; ?>" onchange="getProductData(<?php echo $x; ?>)" >
				  						<option value="">~~SELECT~~</option>
				  						<?php
				  							$productSql = "SELECT * FROM product WHERE active = 1 AND status = 1";
				  							$productData = $connect->query($productSql);

				  							while($row = $productData->fetch_array()) {								 		
				  								echo "<option value='".$row['product_id']."' id='changeProduct".$row['product_id']."'>".$row['product_name']."</option>";
											 	} // /while 

				  						?>
			  						</select>
			  					</div>
			  				</td>
			  				<td style="padding-left:20px;">			  					
			  					<input type="text" name="rate[]" id="rate<?php echo $x; ?>" autocomplete="off" disabled="true" class="form-control" />			  					
			  					<input type="hidden" name="rateValue[]" id="rateValue<?php echo $x; ?>" autocomplete="off" class="form-control" />			  					
			  				</td>
							<td style="padding-left:20px;">
			  					<div class="form-group">
										<p id="available_quantity<?php echo $x; ?>"></p>
			  					</div>
			  				</td>
			  				<td style="padding-left:20px;">
			  					<div class="form-group">
			  					<input type="number" name="quantity[]" id="quantity<?php echo $x; ?>" onkeyup="getTotal(<?php echo $x ?>)" autocomplete="off" class="form-control" min="1" />
			  					</div>
			  				</td>
			  				<td style="padding-left:20px;">			  					
			  					<input type="text" name="total[]" id="total<?php echo $x; ?>" autocomplete="off" class="form-control" disabled="true" />			  					
			  					<input type="hidden" name="totalValue[]" id="totalValue<?php echo $x; ?>" autocomplete="off" class="form-control" />			  					
			  				</td>
			  				<td>

			  					<button class="btn btn-default removeProductRowBtn" type="button" id="removeProductRowBtn" onclick="removeProductRow(<?php echo $x; ?>)"><i class="glyphicon glyphicon-trash"></i></button>
			  				</td>
			  			</tr>
		  			<?php
		  			$arrayNumber++;
			  		} // /for
			  		?>
			  	</tbody>			  	
			  </table>

			  <div class="col-md-6">
			  	<div class="form-group">
				    <label for="subTotal" class="col-sm-3 control-label">Sub Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="subTotal" name="subTotal" disabled="true" />
				      <input type="hidden" class="form-control" id="subTotalValue" name="subTotalValue" />
				    </div>
				  </div> <!--/form-group-->			  
				   <!--/form-group-->			  
				  <div class="form-group">
				    <label for="totalAmount" class="col-sm-3 control-label">Total Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="totalAmount" name="totalAmount" disabled="true"/>
				      <input type="hidden" class="form-control" id="totalAmountValue" name="totalAmountValue" />
				    </div>
				  </div> <!--/form-group-->			  
				  <div class="form-group">
				    <label for="discount" class="col-sm-3 control-label">Discount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="discount" name="discount" onkeyup="discountFunc()" autocomplete="off" />
				    </div>
				  </div> <!--/form-group-->	
				  <div class="form-group">
				    <label for="grandTotal" class="col-sm-3 control-label">Grand Total</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="grandTotal" name="grandTotal" disabled="true" />
				      <input type="hidden" class="form-control" id="grandTotalValue" name="grandTotalValue" />
				    </div>
				  </div> <!--/form-group-->	
			  </div> <!--/col-md-6-->

			  <div class="col-md-6">
			  	<div class="form-group">
				    <label for="paid" class="col-sm-3 control-label">Paid Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="paid" name="paid" autocomplete="off" onkeyup="paidAmount()" />
				    </div>
				  </div> <!--/form-group-->			  
				  <div class="form-group">
				    <label for="due" class="col-sm-3 control-label">Due Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="due" name="due" disabled="true" />
				      <input type="hidden" class="form-control" id="dueValue" name="dueValue" />
				    </div>
				  </div> <!--/form-group-->		
				  <div class="form-group">
				    <label for="paymentType" class="col-sm-3 control-label">Payment Type</label>
				    <div class="col-sm-9">
				      <select class="form-control" name="paymentType" id="paymentType">
				      	<option value="">~~SELECT~~</option>
				      	<option value="1">Cheque</option>
				      	<option value="2">Cash</option>
				      	<option value="3">Credit Card</option>
				      </select>
				    </div>
				  </div> <!--/form-group-->						  
				  <div class="form-group">
				    <label for="paymentStatus" class="col-sm-3 control-label">Payment Status</label>
				    <div class="col-sm-9">
				      <select class="form-control" name="paymentStatus" id="paymentStatus">
				      	<option value="">~~SELECT~~</option>
				      	<option value="1">Full Payment</option>
				      	<option value="2">Advance Payment</option>
				      	<option value="3">No Payment</option>
				      </select>
				    </div>
				  </div> <!--/form-group-->						  
			  </div> <!--/col-md-6-->


			  <div class="form-group submitButtonFooter">
			    <div class="col-sm-offset-2 col-sm-10">
			    <button type="button" class="btn btn-default" onclick="addRow()" id="addRowBtn" data-loading-text="Loading..."> <i class="glyphicon glyphicon-plus-sign"></i> Add Row </button>

			      <button type="submit" id="createPurchaseBtn" data-loading-text="Loading..." class="btn btn-success"><i class="glyphicon glyphicon-ok-sign"></i> Save Changes</button>

			      <button type="reset" class="btn btn-default" onclick="resetPurchaseForm()"><i class="glyphicon glyphicon-erase"></i> Reset</button>
			    </div>
			  </div>
			</form>
		<?php } else if($_GET['o'] == 'manord') { 
			// manage purchase
			?>

			<div id="success-messages"></div>
			
			<table class="table" id="managePurchaseTable">
				<thead>
					<tr>
						<th>#</th>
						<th>Purchase Date</th>
						<th>Supplier</th>
						<th>Total Items</th>
						<th>Payment Status</th>
						<th>Option</th>
					</tr>
				</thead>
			</table>

		<?php 
		// /else manage purchase
		} else if($_GET['o'] == 'editOrd') {
			// get purchase
			?>
			
			<div class="success-messages"></div> <!--/success-messages-->

  		<form class="form-horizontal" method="POST" action="php_action/editPurchase.php" id="editPurchaseForm">

  			<?php $purchaseId = $_GET['i'];

  			$sql = "SELECT purchase_orders.purchase_id, purchase_orders.purchase_date, purchase_orders.supplier_id, purchase_orders.sub_total, purchase_orders.total_amount, purchase_orders.discount, purchase_orders.grand_total, purchase_orders.paid, purchase_orders.due, purchase_orders.payment_type, purchase_orders.payment_status FROM purchase_orders 	
					WHERE purchase_orders.purchase_id = {$purchaseId}";

				$result = $connect->query($sql);
				$data = $result->fetch_row();
  			?>

			  <div class="form-group">
			    <label for="purchaseDate" class="col-sm-2 control-label">Purchase Date</label>
			    <div class="col-sm-10">
			      <input type="text" class="form-control" id="purchaseDate" name="purchaseDate" autocomplete="off" value="<?php echo $data[1] ?>" />
			    </div>
			  </div> <!--/form-group-->
			  <div class="form-group">
			    <label for="supplierId" class="col-sm-2 control-label">Supplier</label>
			    <div class="col-sm-10">
			      <select class="form-control" id="supplierId" name="supplierId">
			      	<option value="">~~SELECT~~</option>
			      	<?php
			      		$supplierSql = "SELECT * FROM suppliers WHERE supplier_active = 1 AND supplier_status = 1";
			      		$supplierData = $connect->query($supplierSql);
			      		while($row = $supplierData->fetch_array()) {
			      			$selected = "";
			      			if($row['supplier_id'] == $data[2]) {
			      				$selected = "selected";
			      			}
			      			echo "<option value='".$row['supplier_id']."' ".$selected.">".$row['supplier_name']."</option>";
			      		}
			      	?>
			      </select>
			    </div>
			  </div> <!--/form-group-->		  

			  <table class="table" id="productTable">
			  	<thead>
			  		<tr>			  			
			  			<th style="width:40%;">Product</th>
			  			<th style="width:20%;">Rate</th>
			  			<th style="width:15%;">In Stock</th>			  			
			  			<th style="width:15%;">Quantity</th>			  			
			  			<th style="width:15%;">Total</th>			  			
			  			<th style="width:10%;"></th>
			  		</tr>
			  	</thead>
			  	<tbody>
			  		<?php

			  		$purchaseItemSql = "SELECT purchase_order_item.purchase_item_id, purchase_order_item.purchase_id, purchase_order_item.product_id, purchase_order_item.quantity, purchase_order_item.rate, purchase_order_item.total FROM purchase_order_item WHERE purchase_order_item.purchase_id = {$purchaseId}";
						$purchaseItemResult = $connect->query($purchaseItemSql);
						
			  		$arrayNumber = 0;
			  		$x = 1;
			  		while($purchaseItemData = $purchaseItemResult->fetch_array()) { 
			  			?>
			  			<tr id="row<?php echo $x; ?>" class="<?php echo $arrayNumber; ?>">			  				
			  				<td style="margin-left:20px;">
			  					<div class="form-group">

				  					<select class="form-control" name="productName[]" id="productName<?php echo $x; ?>" onchange="getProductData(<?php echo $x; ?>)" >
				  						<option value="">~~SELECT~~</option>
				  						<?php
				  							$productSql = "SELECT * FROM product WHERE active = 1 AND status = 1";
				  							$productData = $connect->query($productSql);

				  							while($row = $productData->fetch_array()) {								 		
				  								$selected = "";
				  								if($row['product_id'] == $purchaseItemData['product_id']) {
				  									$selected = "selected";
				  								}

				  								echo "<option value='".$row['product_id']."' id='changeProduct".$row['product_id']."' ".$selected." >".$row['product_name']."</option>";
											 	} // /while 

				  						?>
			  						</select>
			  					</div>
			  				</td>
			  				<td style="padding-left:20px;">			  					
			  					<input type="text" name="rate[]" id="rate<?php echo $x; ?>" autocomplete="off" disabled="true" class="form-control" value="<?php echo $purchaseItemData['rate']; ?>" />			  					
			  					<input type="hidden" name="rateValue[]" id="rateValue<?php echo $x; ?>" autocomplete="off" class="form-control" value="<?php echo $purchaseItemData['rate']; ?>" />			  					
			  				</td>
							<td style="padding-left:20px;">
			  					<div class="form-group">
										<?php
			  							$productSql = "SELECT * FROM product WHERE active = 1 AND status = 1";
			  							$productData = $connect->query($productSql);

			  							while($row = $productData->fetch_array()) {								 		
			  								if($row['product_id'] == $purchaseItemData['product_id']) { 
			  									echo "<p id='available_quantity".$row['product_id']."'>".$row['quantity']."</p>";
			  								}
										 	} // /while 

			  						?>
			  					</div>
			  				</td>
			  				<td style="padding-left:20px;">
			  					<div class="form-group">
			  					<input type="number" name="quantity[]" id="quantity<?php echo $x; ?>" onkeyup="getTotal(<?php echo $x ?>)" autocomplete="off" class="form-control" min="1" value="<?php echo $purchaseItemData['quantity']; ?>" />
			  					</div>
			  				</td>
			  				<td style="padding-left:20px;">			  					
			  					<input type="text" name="total[]" id="total<?php echo $x; ?>" autocomplete="off" class="form-control" disabled="true" value="<?php echo $purchaseItemData['total']; ?>"/>			  					
			  					<input type="hidden" name="totalValue[]" id="totalValue<?php echo $x; ?>" autocomplete="off" class="form-control" value="<?php echo $purchaseItemData['total']; ?>"/>			  					
			  				</td>
			  				<td>

			  					<button class="btn btn-default removeProductRowBtn" type="button" id="removeProductRowBtn" onclick="removeProductRow(<?php echo $x; ?>)"><i class="glyphicon glyphicon-trash"></i></button>
			  				</td>
			  			</tr>
		  			<?php
		  			$arrayNumber++;
		  			$x++;
			  		} // /for
			  		?>
			  	</tbody>			  	
			  </table>

			  <div class="col-md-6">
			  	<div class="form-group">
				    <label for="subTotal" class="col-sm-3 control-label">Sub Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="subTotal" name="subTotal" disabled="true" value="<?php echo $data[3] ?>" />
				      <input type="hidden" class="form-control" id="subTotalValue" name="subTotalValue" value="<?php echo $data[3] ?>" />
				    </div>
				  </div> <!--/form-group-->			  
				  			  
				  <div class="form-group">
				    <label for="totalAmount" class="col-sm-3 control-label">Total Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="totalAmount" name="totalAmount" disabled="true" value="<?php echo $data[4] ?>" />
				      <input type="hidden" class="form-control" id="totalAmountValue" name="totalAmountValue" value="<?php echo $data[4] ?>"  />
				    </div>
				  </div> <!--/form-group-->			  
				  <div class="form-group">
				    <label for="discount" class="col-sm-3 control-label">Discount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="discount" name="discount" onkeyup="discountFunc()" autocomplete="off" value="<?php echo $data[5] ?>" />
				    </div>
				  </div> <!--/form-group-->	
				  <div class="form-group">
				    <label for="grandTotal" class="col-sm-3 control-label">Grand Total</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="grandTotal" name="grandTotal" disabled="true" value="<?php echo $data[6] ?>"  />
				      <input type="hidden" class="form-control" id="grandTotalValue" name="grandTotalValue" value="<?php echo $data[6] ?>"  />
				    </div>
				  </div> <!--/form-group-->	
			  </div> <!--/col-md-6-->

			  <div class="col-md-6">
			  	<div class="form-group">
				    <label for="paid" class="col-sm-3 control-label">Paid Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="paid" name="paid" autocomplete="off" onkeyup="paidAmount()" value="<?php echo $data[7] ?>"  />
				    </div>
				  </div> <!--/form-group-->			  
				  <div class="form-group">
				    <label for="due" class="col-sm-3 control-label">Due Amount</label>
				    <div class="col-sm-9">
				      <input type="text" class="form-control" id="due" name="due" disabled="true" value="<?php echo $data[8] ?>"  />
				      <input type="hidden" class="form-control" id="dueValue" name="dueValue" value="<?php echo $data[8] ?>"  />
				    </div>
				  </div> <!--/form-group-->		
				  <div class="form-group">
				    <label for="paymentType" class="col-sm-3 control-label">Payment Type</label>
				    <div class="col-sm-9">
				      <select class="form-control" name="paymentType" id="paymentType" >
				      	<option value="">~~SELECT~~</option>
				      	<option value="1" <?php if($data[9] == 1) {
				      		echo "selected";
				      	} ?> >Cheque</option>
				      	<option value="2" <?php if($data[9] == 2) {
				      		echo "selected";
				      	} ?>  >Cash</option>
				      	<option value="3" <?php if($data[9] == 3) {
				      		echo "selected";
				      	} ?> >Credit Card</option>
				      </select>
				    </div>
				  </div> <!--/form-group-->						  
				  <div class="form-group">
				    <label for="paymentStatus" class="col-sm-3 control-label">Payment Status</label>
				    <div class="col-sm-9">
				      <select class="form-control" name="paymentStatus" id="paymentStatus">
				      	<option value="">~~SELECT~~</option>
				      	<option value="1" <?php if($data[10] == 1) {
				      		echo "selected";
				      	} ?>  >Full Payment</option>
				      	<option value="2" <?php if($data[10] == 2) {
				      		echo "selected";
				      	} ?> >Advance Payment</option>
				      	<option value="3" <?php if($data[8] == 3) {
				      		echo "selected";
				      	} ?> >No Payment</option>
				      </select>
				    </div>
				  </div> <!--/form-group-->						  
			  </div> <!--/col-md-6-->


			  <div class="form-group editButtonFooter">
			    <div class="col-sm-offset-2 col-sm-10">
			    <button type="button" class="btn btn-default" onclick="addRow()" id="addRowBtn" data-loading-text="Loading..."> <i class="glyphicon glyphicon-plus-sign"></i> Add Row </button>

			    <input type="hidden" name="purchaseId" id="purchaseId" value="<?php echo $_GET['i']; ?>" />

			    <button type="submit" id="editPurchaseBtn" data-loading-text="Loading..." class="btn btn-success"><i class="glyphicon glyphicon-ok-sign"></i> Save Changes</button>
			      
			    </div>
			  </div>
			</form>

			<?php
		} // /get purchase else  ?>


	</div> <!--/panel-->	
</div> <!--/panel-->	


<!-- remove purchase -->
<div class="modal fade" tabindex="-1" role="dialog" id="removePurchaseModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><i class="glyphicon glyphicon-trash"></i> Remove Purchase</h4>
      </div>
      <div class="modal-body">

      	<div class="removePurchaseMessages"></div>

        <p>Do you really want to remove ?</p>
      </div>
      <div class="modal-footer removePurchaseFooter">
        <button type="button" class="btn btn-default" data-dismiss="modal"> <i class="glyphicon glyphicon-remove-sign"></i> Close</button>
        <button type="button" class="btn btn-primary" id="removePurchaseBtn" data-loading-text="Loading..."> <i class="glyphicon glyphicon-ok-sign"></i> Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- /remove purchase-->


<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script src="custom/js/purchase.js"></script>

<?php require_once 'includes/footer.php'; ?>